:HL["/_next/static/chunks/040lxy-stmg_j.css","style"]
0:{"tree":{"name":"","param":null,"prefetchHints":4176,"slots":{"children":{"name":"__PAGE__","param":null,"prefetchHints":4256,"slots":null}}},"staleTime":300,"buildId":"Qgnj40JqZAQSFPe6BsHKE"}
