module.exports=[13506,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_findings_%5Bid%5D_page_actions_1_uoakq.js.map